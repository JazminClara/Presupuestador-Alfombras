package com.dimensionrug.presupuestar.entidades;

public class Hilado {
    private Integer idHilado;
    private String nombre;
    private String color;
    private Double precioKilo;
    private Double consumoM2;
    private Double precioM2;
}
