package com.dimensionrug.presupuestar.services;

import java.sql.SQLException;
import java.util.List;

import org.springframework.stereotype.Service;

import com.dimensionrug.presupuestar.models.entities.ManoDeObra;
import com.dimensionrug.presupuestar.models.repositories.interfaces.I_ManoDeObraRepository;

@Service
public class ManoDeObraService {

    private final I_ManoDeObraRepository manoDeObraRepository;

    public ManoDeObraService(I_ManoDeObraRepository manoDeObraRepository) {
        this.manoDeObraRepository = manoDeObraRepository;
    }

    public List<ManoDeObra> obtenerTodasLasManosDeObra() throws SQLException {
        return manoDeObraRepository.findAll();
    }

    public ManoDeObra guardarManoDeObra(ManoDeObra manoDeObra) throws SQLException {
        if (manoDeObra.getIdTrabajo() != null) {
            manoDeObraRepository.update(manoDeObra);
        } else {
            manoDeObraRepository.create(manoDeObra);
        }
        return manoDeObra;
    }

    public ManoDeObra buscarManoDeObraPorId(Integer id) throws SQLException {
        return manoDeObraRepository.findById(id);
    }

    public boolean elimanarManoDeObra(Integer id) throws SQLException {
        return manoDeObraRepository.delete(id);
    }
}
