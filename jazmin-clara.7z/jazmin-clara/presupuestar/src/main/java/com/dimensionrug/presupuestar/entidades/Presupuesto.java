package com.dimensionrug.presupuestar.entidades;

public class Presupuesto {
    private Integer idPresupuesto;
    private String nombreCliente;
    private Double anchoAlfombra;
    private Double largoAlfombra;
    private Integer idTelaBase;
    private Integer idTelaFondo;
    private Integer idHilado;
    private Integer idPegamento;
    private Integer idTrabajo;
    private Double precioTotal;
}
