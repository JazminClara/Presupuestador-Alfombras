package com.dimensionrug.presupuestar.enums;

public enum Uso {
    BASE, FONDO;
}
