package com.dimensionrug.presupuestar.controllers;

import java.sql.SQLException;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.dimensionrug.presupuestar.models.entities.ManoDeObra;
import com.dimensionrug.presupuestar.services.ManoDeObraService;

@Controller
public class ManoDeObraController {
    private final ManoDeObraService manoDeObraService;

    public ManoDeObraController(ManoDeObraService manoDeObraService) {
        this.manoDeObraService = manoDeObraService;
    }

    @GetMapping("/manos-de-obra")
    public String listarManosDeObra(Model model) {
        try {
            List<ManoDeObra> manosDeObra = manoDeObraService.obtenerTodasLasManosDeObra();
            model.addAttribute("manosDeObra", manosDeObra);
        } catch (SQLException e) {
            e.printStackTrace();
            model.addAttribute("errorTablas", "Error en cargar tablas de Mano de Obra" + e.getMessage());
        }
        return "manos-de-obra-lista";
    }

    @GetMapping("/mano-de-obra/alta")
    public String altaManoDeObraForm(Model model) {
        model.addAttribute("manoDeObra", new ManoDeObra());
        return "mano-de-obra-alta";
    }

    @PostMapping("/mano-de-obra/guardar")
    public String guardarManoDeObra(@ModelAttribute("manoDeObra") ManoDeObra manoDeObra, Model model) {
        try {
            manoDeObraService.guardarManoDeObra(manoDeObra);
            return "redirect:/manos-de-obra";
        } catch (SQLException e) {
            e.printStackTrace();
            model.addAttribute("errorGuardar", "Error al guardar el mano de obra" + e.getMessage());
            return "mano-de-obra-alta";
        }
    }

    @GetMapping("/mano-de-obra/editar")
    public String editarTrabajo(@RequestParam("id") int id, Model model) {
        try {
            ManoDeObra manoDeObra = manoDeObraService.buscarManoDeObraPorId(id);
            if (manoDeObra != null) {
                model.addAttribute("manoDeObra", manoDeObra);
                return "mano-de-obra-editar";
            } else {
                return "redirect:/manos-de-obra";
            }
        } catch (SQLException e) {
            e.printStackTrace();
            model.addAttribute("errorId", "Error al buscar id de trabajo para editar" + e.getMessage());
            return "manos-de-obra-lista";
        }
    }

    @PostMapping("mano-de-obra/actualizar")
    public String actualizarTrabajo(@ModelAttribute("mano-de-obra") ManoDeObra manoDeObra, Model model) {
        try {
            manoDeObraService.guardarManoDeObra(manoDeObra);
            return "redirect:/manos-de-obra";
        } catch (SQLException e) {
            e.printStackTrace();
            model.addAttribute("errorGuardar", "Eror al guardar la mano de obra" + e.getMessage());
            model.addAttribute("manoDeObra", manoDeObra);
            return "manos-de-obra-editar";
        } catch (IllegalArgumentException ex) {
            ex.printStackTrace();
            model.addAttribute("errorGuardar", "Eror al guardar la mano de obra" + ex.getMessage());
            model.addAttribute("manoDeObra", manoDeObra);
            return "mano-de-obra-editar";
        }
    }

    @GetMapping("/mano-de-obra/eliminar")
    public String eliminarManoDeObra(@RequestParam("id") int id, Model model) {
        try {
            manoDeObraService.elimanarManoDeObra(id);
            return "redirect:/manos-de-obra";
        } catch (SQLException e) {
            e.printStackTrace();
            model.addAttribute("errorEliminar", "Error al eliminar la mano de obra" + e.getMessage());
            try {
                model.addAttribute("manosDeObra", manoDeObraService.obtenerTodasLasManosDeObra());
            } catch (SQLException ex) {
                ex.printStackTrace();
                model.addAttribute("errorTablasAlEliminar", "Error al cargar manos de obra luego de eliminación fallida" + ex.getMessage());
            }
            return "manos-de-obra-lista";
        }
    }
}
