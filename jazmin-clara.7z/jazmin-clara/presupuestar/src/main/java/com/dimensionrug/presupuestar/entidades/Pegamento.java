package com.dimensionrug.presupuestar.entidades;

public class Pegamento {
    private Integer idPegamento;
    private String nombre;
    private Double precioKilo;
    private Double consumoM2;
    private Double precioM2;
}
