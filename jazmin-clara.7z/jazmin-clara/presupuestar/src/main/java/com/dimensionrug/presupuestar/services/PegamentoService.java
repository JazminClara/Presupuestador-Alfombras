package com.dimensionrug.presupuestar.services;

import java.sql.SQLException;
import java.util.List;

import org.springframework.stereotype.Service;

import com.dimensionrug.presupuestar.models.entities.Pegamento;
import com.dimensionrug.presupuestar.models.repositories.interfaces.I_PegamentoRepository;

@Service
public class PegamentoService {
    private final I_PegamentoRepository pegamentoRepository;

    public PegamentoService(I_PegamentoRepository pegamentoRepository) {
        this.pegamentoRepository = pegamentoRepository;
    }

    public List<Pegamento> obtenerTodosLosPegamentos() throws SQLException {
        return pegamentoRepository.findAll();
    }

    public Pegamento guardarPegamento(Pegamento pegamento) throws SQLException {
        pegamento.calcularprecioM2();
        if (pegamento.getIdPegamento() != null) {
            pegamentoRepository.update(pegamento);
        } else {
            pegamentoRepository.create(pegamento);
        }
        return pegamento;
    }

    public Pegamento buscarPegamentoPorId (Integer id) throws SQLException {
        return pegamentoRepository.findById(id);
    }

    public boolean eliminarPregamento(Integer id) throws SQLException {
        return pegamentoRepository.delete(id);
    }
}
