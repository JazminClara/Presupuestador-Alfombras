package com.dimensionrug.presupuestar.models.entities;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class Hilado {
    private Integer idHilado;
    private String nombre;
    private String color;
    private Double precioKilo;
    private Double consumoM2;
    private Double precioM2;

    public Hilado(Integer idHilado, String nombre, String color, Double precioKilo, Double consumoM2) {
        this.idHilado = idHilado;
        this.nombre = nombre;
        this.color = color;
        this.precioKilo = precioKilo;
        this.consumoM2 = consumoM2;
        //precioM2 se calcula con una regla de 3 simples en base a: precioKilo y consumoM2
        this.calcularPrecioM2();
    }

    public void calcularPrecioM2() {
        this.precioM2 = consumoM2 * precioKilo;
    }
}
