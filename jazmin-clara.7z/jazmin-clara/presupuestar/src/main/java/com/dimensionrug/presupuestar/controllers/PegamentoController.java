package com.dimensionrug.presupuestar.controllers;


import java.sql.SQLException;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.dimensionrug.presupuestar.models.entities.Pegamento;
import com.dimensionrug.presupuestar.services.PegamentoService;

@Controller
public class PegamentoController {
    private PegamentoService pegamentoService;

    public PegamentoController(PegamentoService pegamentoService) {
        this.pegamentoService = pegamentoService;
    }

    @GetMapping("/pegamentos")
    public String listarPegamentos(Model model) {
        try {
            List<Pegamento> pegamentos = pegamentoService.obtenerTodosLosPegamentos();
            model.addAttribute("pegamentos", pegamentos);
        } catch (SQLException e) {
            e.printStackTrace();
            model.addAttribute("errorTablas", "Error en cargar tablas de Pegamentos" + e.getMessage());
        }
        return "pegamentos-lista";
    }

    @GetMapping("/pegamento/alta")
    public String altaPegamentoForm(Model model) {
        model.addAttribute("pegamento", new Pegamento());
        return "pegamento-alta";
    }

    @PostMapping("/pegamento/guardar")
    public String guardarPegamento(@ModelAttribute("pegamento") Pegamento pegamento, Model model) {
        try {
            pegamentoService.guardarPegamento(pegamento);
            return "redirect:/pegamentos";
        } catch (SQLException e) {
            e.printStackTrace();
            model.addAttribute("errorGuardar", "Error al guardar el pegamento" + e.getMessage());
            return "pegamento-alta";
        }
    }

    @GetMapping("/pegamento/editar")
    public String editarPegamento(@RequestParam("id") int id, Model model) {
        try {
            Pegamento pegamento = pegamentoService.buscarPegamentoPorId(id);
            if (pegamento != null) {
                model.addAttribute("pegamento", pegamento);
                return "pegamento-editar";
            } else {
                return "redirect:/pegamentos";
            }
        } catch (SQLException e) {
            e.printStackTrace();
            model.addAttribute("errorId", "Error al buscar id del pegamento para editar" + e.getMessage());
            return "pegamentos-lista";                                                                                // Falta vista
        }
    }

    @PostMapping("pegamento/actualizar")
    public String actualizarPegamento(@ModelAttribute("pegamento") Pegamento pegamento, Model model) {
        try {
            pegamentoService.guardarPegamento(pegamento);
            return "redirect:/pegamentos";
        } catch (SQLException e) {
            e.printStackTrace();
            model.addAttribute("errorGuardar", "Eror al guardar la pegamento" + e.getMessage());
            model.addAttribute("pegamento", pegamento);
            return "pegamento-editar";
        } catch (IllegalArgumentException ex) {
            ex.printStackTrace();
            model.addAttribute("errorGuardar", "Eror al guardar la pegamento" + ex.getMessage());
            model.addAttribute("pegamento", pegamento);
            return "pegamento-editar";
        }
    }

    @GetMapping("/pegamento/eliminar")
    public String eliminarPegamento(@RequestParam("id") int id, Model model) {
        try {
            pegamentoService.eliminarPregamento(id);
            return "redirect:/pegamentos";
        } catch (SQLException e) {
            e.printStackTrace();
            model.addAttribute("errorEliminar", "Error al eliminar la pegamento" + e.getMessage());
            try {
                model.addAttribute("pegamentos", pegamentoService.obtenerTodosLosPegamentos());
            } catch (SQLException ex) {
                ex.printStackTrace();
                model.addAttribute("errorTablasAlEliminar", "Error al cargar pegamentos luego de eliminación fallida" + ex.getMessage());
            }
            return "pegamentos-lista";
        } 

    }
}
