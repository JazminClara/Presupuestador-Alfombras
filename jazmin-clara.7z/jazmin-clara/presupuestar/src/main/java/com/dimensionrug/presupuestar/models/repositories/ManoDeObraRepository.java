package com.dimensionrug.presupuestar.models.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.stereotype.Repository;

import com.dimensionrug.presupuestar.models.entities.ManoDeObra;
import com.dimensionrug.presupuestar.models.repositories.interfaces.I_ManoDeObraRepository;

@Repository
public class ManoDeObraRepository implements I_ManoDeObraRepository {

    private final DataSource dataSource;

    public ManoDeObraRepository(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    private static final String SQL_CREATE = "INSERT INTO mano_de_obra (nombre, precio_hora) values (?,?)";
    private static final String SQL_UPDATE = "UPDATE mano_de_obra SET nombre=?, precio_hora=? WHERE id_trabajo=?";
    private static final String SQL_DELETE = "DELETE FROM mano_de_obra WHERE id_trabajo=?";
    private static final String SQL_FIND_BY_ID = "SELECT * FROM mano_de_obra WHERE id_trabajo=?";
    private static final String SQL_FIND_ALL = "SELECT * FROM mano_de_obra";

    @Override
    public void create(ManoDeObra manoDeObra) throws SQLException {
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_CREATE, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, manoDeObra.getNombre());
            ps.setDouble(2, manoDeObra.getPrecioHora());

            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) manoDeObra.setIdTrabajo(keys.getInt(1));
            }
        }
    }

    @Override
    public int update(ManoDeObra manoDeObra) throws SQLException {
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_UPDATE)) {
            ps.setString(1, manoDeObra.getNombre());
            ps.setDouble(2, manoDeObra.getPrecioHora());
            ps.setInt(3, manoDeObra.getIdTrabajo());

            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas;
        }
    }

    @Override
    public boolean delete(Integer id) throws SQLException {
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_DELETE)) {
            ps.setInt(1, id);

            boolean manoDeObraBorrada = ps.executeUpdate() ==1;
            return manoDeObraBorrada;
        }
    }

    @Override
    public ManoDeObra findById(Integer id) throws SQLException {
        try (Connection conn = dataSource.getConnection(); PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_ID)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapRow(rs);
            }
            return null;
        } 
    }

    @Override
    public List<ManoDeObra> findAll() throws SQLException {
        List <ManoDeObra> lista = new ArrayList<>();
        try (Connection conn = dataSource.getConnection(); PreparedStatement ps = conn.prepareStatement(SQL_FIND_ALL);
                ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(mapRow(rs));
            }
        }
        return lista;
    }

    private ManoDeObra mapRow(ResultSet rs) throws SQLException {
        ManoDeObra trabajo = new ManoDeObra();
        trabajo.setIdTrabajo(rs.getInt("id_trabajo"));
        trabajo.setNombre(rs.getString("nombre"));
        trabajo.setPrecioHora(rs.getDouble("precio_hora"));
        return trabajo;
    }
}
