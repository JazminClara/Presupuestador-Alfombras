package com.dimensionrug.presupuestar.entidades;

import com.dimensionrug.presupuestar.enums.Uso;

public class Tela {
    private Integer idTela;
    private String nombre;
    private Uso uso;
    private Double anchoFabrica;
    private Double precioMetro;
    private Double precioM2;
}
