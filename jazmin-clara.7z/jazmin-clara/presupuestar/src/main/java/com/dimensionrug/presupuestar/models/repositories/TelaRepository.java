package com.dimensionrug.presupuestar.models.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.stereotype.Repository;

import com.dimensionrug.presupuestar.models.entities.Tela;
import com.dimensionrug.presupuestar.models.enums.Uso;
import com.dimensionrug.presupuestar.models.repositories.interfaces.I_TelaRepository;

@Repository
public class TelaRepository implements I_TelaRepository{
    private final DataSource dataSource;

    public TelaRepository(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    private static final String SQL_CREATE = "INSERT INTO telas (nombre, uso, ancho_fabrica, precio_metro, precio_m2) values (?,?,?,?,?)";
    private static final String SQL_UPDATE = "UPDATE telas SET nombre=?, uso=?, ancho_fabrica=?, precio_metro=?, precio_m2=? WHERE id_tela=?";
    private static final String SQL_DELETE = "DELETE FROM telas WHERE id_tela = ?";
    private static final String SQL_FIND_BY_ID = "SELECT * FROM telas WHERE id_tela = ?";
    private static final String SQL_FIND_ALL = "SELECT * FROM telas";

    @Override
    public void create(Tela tela) throws SQLException {
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_CREATE, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, tela.getNombre());
            ps.setString(2, tela.getUso().name());
            ps.setDouble(3, tela.getAnchoFabrica());
            ps.setDouble(4, tela.getPrecioMetro());
            ps.setDouble(5, tela.getPrecioM2());

            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) tela.setIdTela(keys.getInt(1));                
            }
        } 
    }

    @Override
    public int update(Tela tela) throws SQLException {
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_UPDATE)) {
            ps.setString(1, tela.getNombre());
            ps.setString(2, tela.getUso().name());
            ps.setDouble(3, tela.getAnchoFabrica());
            ps.setDouble(4, tela.getPrecioMetro());
            ps.setDouble(5, tela.getPrecioM2());
            ps.setInt(6, tela.getIdTela());

            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas;
        }
    }

    @Override
    public boolean delete(Integer id) throws SQLException {
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_DELETE)) {
            ps.setInt(1, id);

            boolean telaBorrada = ps.executeUpdate() ==1;
            return telaBorrada;
        }
    }

    @Override
    public Tela findById(Integer id) throws SQLException {
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_ID)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapRow(rs);
            }
        } 
        return null;
    }

    @Override
    public List<Tela> findAll() throws SQLException {
        List<Tela> lista = new ArrayList<>();
        try (Connection conn = dataSource.getConnection(); PreparedStatement ps = conn.prepareStatement(SQL_FIND_ALL);
                ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(mapRow(rs));
            }
        } 
        return lista;
    }

    private Tela mapRow(ResultSet rs) throws SQLException {
        Tela tela = new Tela();
        tela.setIdTela(rs.getInt("id_tela"));
        tela.setNombre(rs.getString("nombre"));
        tela.setUso(Uso.valueOf(rs.getString("uso")));
        tela.setAnchoFabrica(rs.getDouble("ancho_fabrica"));
        tela.setPrecioMetro(rs.getDouble("precio_metro"));
        tela.calcularPrecioM2();
        return tela;
    }
}
