package com.dimensionrug.presupuestar.models.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Presupuesto {
    private Integer idPresupuesto;
    private String nombreCliente;
    private Double anchoAlfombra;
    private Double largoAlfombra;
    private Integer idTelaBase;
    private Integer idTelaFondo;
    private Integer idHilado;
    private Integer idPegamento;
    private Integer idTrabajo;
    private Double precioTotal;
}