package com.dimensionrug.presupuestar.entidades;

public class ManoDeObra {
    private Integer idTrabajo;
    private String nombre;
    private Double precioHora;
}
