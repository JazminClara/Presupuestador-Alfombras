package com.dimensionrug.presupuestar.services;

import java.sql.SQLException;
import java.util.List;

import org.springframework.stereotype.Service;

import com.dimensionrug.presupuestar.models.entities.Tela;
import com.dimensionrug.presupuestar.models.repositories.interfaces.I_TelaRepository;

@Service
public class TelaService {
    private final I_TelaRepository telaRepository;

    public TelaService(I_TelaRepository telaRepository) {
        this.telaRepository = telaRepository;
    }

    public List<Tela> obtenerTodasLasTelas() throws SQLException {
        return telaRepository.findAll();
    }
    
    public Tela guardarTela(Tela tela) throws SQLException {
        // Calcalurá el atributo precioM2 antes de guardar en la base de datos
        tela.calcularPrecioM2();
        if (tela.getIdTela() != null) {
            telaRepository.update(tela);
        } else {
            telaRepository.create(tela);
        }
        return tela;
    }

    public Tela buscarTelaPorIdTela(Integer id) throws SQLException {
        return telaRepository.findById(id);
    }
 
    public boolean eliminarTela(Integer id) throws SQLException {
        return telaRepository.delete(id);
    }
}
