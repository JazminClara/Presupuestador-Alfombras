package com.dimensionrug.presupuestar.test;

import java.io.InputStream;
import java.sql.Connection;
import java.util.Properties;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

public class TestConnection {
    public static void main(String[] args) {

        Properties prop = new Properties();

        try (InputStream in = TestConnection.class.getClassLoader().getResourceAsStream("application.properties")) {
            if (in == null) {
                System.err.println("No se encontró archivo con propiedades");
                return;
            }
            prop.load(in);
        } catch (Exception e) {
            System.err.println("Fallo en carga de propiedades: " + e.getMessage());
        }


        
        HikariConfig configuracion = new HikariConfig();
        configuracion.setJdbcUrl(prop.getProperty("spring.datasource.url"));
        configuracion.setUsername(prop.getProperty("spring.datasource.username"));
        configuracion.setPassword(prop.getProperty("spring.datasource.password"));

        
        
        try (HikariDataSource ds = new HikariDataSource(configuracion);
                Connection conn = ds.getConnection()) { 
            if(conn.isValid(2)){
                System.out.println("Conectado a: " + conn.getMetaData().getURL());
            } else{
                System.err.println("La conexión no es válida");
            }
        } catch (Exception e) {
            System.err.println("No se pudo conectar " + e.getMessage());
        }
    }
}
