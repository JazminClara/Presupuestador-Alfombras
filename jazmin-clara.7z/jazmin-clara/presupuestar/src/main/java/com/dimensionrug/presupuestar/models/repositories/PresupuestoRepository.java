package com.dimensionrug.presupuestar.models.repositories;

import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.stereotype.Repository;

import com.dimensionrug.presupuestar.models.entities.Presupuesto;
import com.dimensionrug.presupuestar.models.repositories.interfaces.I_PresupuestoRepository;

@Repository
public class PresupuestoRepository implements I_PresupuestoRepository{
    private final DataSource dataSource;

    public PresupuestoRepository(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    private static final String SQL_CREATE = 
    "INSERT INTO presupuestos (nombre_cliente, ancho_alfombra, largo_alfombra, id_tela_base, id_tela_fondo, id_hilado, id_pegamento, id_trabajo, precio_total) VALUES (?,?,?,?,?,?,?,?,?)";
    private static final String SQL_UPDATE =
    "UPDATE presupuestos SET nombre_cliente=?, ancho_alfombra=?, largo_alfombra=?, id_tela_base=?, id_tela_fondo=?, id_hilado=?, id_pegamento=?, id_trabajo=?, precio_total=? WHERE id_presupuesto=?";
    private static final String SQL_DELETE = "DELETE FROM presupuestos WHERE id_presupuesto=?";
    private static final String SQL_FIND_BY_ID = "SELECT * FROM presupuestos WHERE id_presupuesto=?";
    private static final String SQL_FIND_ALL = "SELECT * FROM presupuestos";

    @Override
    public void create(Presupuesto presupuesto) throws SQLException {
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_CREATE, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, presupuesto.getNombreCliente());
            ps.setDouble(2, presupuesto.getAnchoAlfombra());
            ps.setDouble(3, presupuesto.getLargoAlfombra());
            ps.setInt(4, presupuesto.getIdTelaBase());
            ps.setInt(5, presupuesto.getIdTelaFondo());
            ps.setInt(6, presupuesto.getIdHilado());
            ps.setInt(7, presupuesto.getIdPegamento());
            ps.setInt(8, presupuesto.getIdTrabajo());
            if (presupuesto.getPrecioTotal()!= null) {
                ps.setDouble(9, presupuesto.getPrecioTotal());
            } else {
                ps.setObject(9, null);
            }

            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) presupuesto.setIdPresupuesto(keys.getInt(1)); 
            }
        }
    }

    @Override
    public int update(Presupuesto presupuesto) throws SQLException {
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_UPDATE)) {
            ps.setString(1, presupuesto.getNombreCliente());
            ps.setDouble(2, presupuesto.getAnchoAlfombra());
            ps.setDouble(3, presupuesto.getLargoAlfombra());
            ps.setInt(4, presupuesto.getIdTelaBase());
            ps.setInt(5, presupuesto.getIdTelaFondo());
            ps.setInt(6, presupuesto.getIdHilado());
            ps.setInt(7, presupuesto.getIdPegamento());
            ps.setInt(8, presupuesto.getIdTrabajo());
            if (presupuesto.getPrecioTotal()!= null) {
                ps.setDouble(9, presupuesto.getPrecioTotal());
            } else {
                ps.setObject(9, null);
            }
            ps.setInt(10, presupuesto.getIdPresupuesto());

            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas;
        } 
    }

    @Override
    public boolean delete(Integer id) throws SQLException {
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_DELETE)) {
            ps.setInt(1, id);

            boolean presupuestoBorrado = ps.executeUpdate() ==1;
            return presupuestoBorrado;
        }
    }

    @Override
    public Presupuesto findById(Integer id) throws SQLException {
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_ID)) {
            ps.setInt(1, id);
            
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapRow(rs);
            }
        } 
        return null;
    }

    @Override
    public List<Presupuesto> findAll() throws SQLException {
        List<Presupuesto> lista = new ArrayList<>();
        try (Connection conn = dataSource.getConnection(); PreparedStatement ps = conn.prepareStatement(SQL_FIND_ALL);
                ResultSet rs = ps.executeQuery()) {
            while (rs.next()) lista.add(mapRow(rs));
        }
        return lista;
    }

    private Presupuesto mapRow(ResultSet rs) throws SQLException {
        Presupuesto presupuesto = new Presupuesto();
        presupuesto.setIdPresupuesto(rs.getInt("id_presupuesto"));
        presupuesto.setNombreCliente(rs.getString("nombre_cliente"));
        presupuesto.setAnchoAlfombra(rs.getDouble("ancho_alfombra"));
        presupuesto.setLargoAlfombra(rs.getDouble("largo_alfombra"));
        presupuesto.setIdTelaBase(rs.getInt("id_tela_base"));
        presupuesto.setIdTelaFondo(rs.getInt("id_tela_fondo"));
        presupuesto.setIdHilado(rs.getInt("id_hilado"));
        presupuesto.setIdPegamento(rs.getInt("id_pegamento"));
        presupuesto.setIdTrabajo(rs.getInt("id_trabajo"));
        presupuesto.setPrecioTotal(rs.getDouble("precio_total"));
        return presupuesto;
    }
}
