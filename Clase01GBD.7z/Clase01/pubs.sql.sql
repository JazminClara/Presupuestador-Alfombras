-- Funciones de Agrupacion

use pubs;

-- 1. Listar la cantidad de libros de la base

select count(*) from titles;

-- 2. Listar la suma de los precios de los libros

select round(sum(price),2) from titles;
select truncate(sum(price), 2) from titles;

-- 3. Listar el promedio de horas trabajadas por los empleados

select avg(job_lvl) from employee;

-- 4. Listar el precio del titulo más caro

select max(price) from titles;

-- 5. Listar el precio del titulo más económico

select min(price) from titles;

-- 6. Nombre del libro más barato

select title 'nombre' from titles where price = (select min(price)from titles);

-- 7. Lstar el nombre contatenado con el útimotitulo publicado

select contact(a.au_fname, ' ', a.au_lname) 'Autor' from titles t 
join tittleauthors ta on t.title_id = ta.au_id
join author a on ta.au_id = a.au_id
where t.pubdate = (select max(pubdate) from titles);

select contact(a.au_fname, ' ', a.au_lname) 'Autor' from author a 
inner join tittleauthors ta on a.au_id = ta.au_id
inner join titles t on ta.tittle_id = t.tittle_id
where t.pubdate = (select max(pubdate) from titles);

-- 8 Mostrar el nombre de las editoriales que no hayan publicado ningún libro

select pub_name from publishers p 
where p.pub_id not in (select pub_id from titles);

-- 8. cuál es la tabla principal? Es de la cúal queremos obtener datos: publishers

select pub_name 'Editorial' from publishers p left join titles t on p.pub_id = t.pub_id
where t.title_id is null;

-- 9. Mostrar el nombre de los libros que nunca fueron vendidos

select t.title from titles t left join sales s on t.title_id = s.title_id
where s.title_id is null;

