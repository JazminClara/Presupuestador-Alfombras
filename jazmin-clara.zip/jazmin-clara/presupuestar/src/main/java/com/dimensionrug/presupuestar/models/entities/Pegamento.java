package com.dimensionrug.presupuestar.models.entities;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class Pegamento {
    private Integer idPegamento;
    private String nombre;
    private Double precioKilo;
    private Double consumoM2;
    private Double precioM2;

    public Pegamento(Integer idPegamento, String nombre, Double precioKilo, Double consumoM2) {
        this.idPegamento = idPegamento;
        this.nombre = nombre;
        this.precioKilo = precioKilo;
        this.consumoM2 = consumoM2;
        this.precioM2 = consumoM2 * precioKilo;
    }
}
