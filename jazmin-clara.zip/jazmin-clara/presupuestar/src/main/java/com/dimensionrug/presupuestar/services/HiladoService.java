package com.dimensionrug.presupuestar.services;

import java.sql.SQLException;
import java.util.List;

import org.springframework.stereotype.Service;

import com.dimensionrug.presupuestar.models.entities.Hilado;
import com.dimensionrug.presupuestar.models.repositories.interfaces.I_HiladoRepository;

@Service
public class HiladoService {
    private final I_HiladoRepository hiladoRepository;

    public HiladoService(I_HiladoRepository hiladoRepository) {
        this.hiladoRepository = hiladoRepository;
    }

    public List<Hilado> obtenerTodosLosHilados() throws SQLException {
        return hiladoRepository.findAll();
    }

    public Hilado guardarHilado(Hilado hilado) throws SQLException {
        hilado.calcularPrecioM2();
        if (hilado.getIdHilado() != null) {
            hiladoRepository.update(hilado);
        } else {
            hiladoRepository.create(hilado);
        }
        return hilado;
    }

    public Hilado buscarHiladoPorId(Integer id) throws SQLException {
        return hiladoRepository.findById(id);
    }

    public boolean elimanarHilado(Integer id) throws SQLException {
        return hiladoRepository.delete(id);
    }
}
