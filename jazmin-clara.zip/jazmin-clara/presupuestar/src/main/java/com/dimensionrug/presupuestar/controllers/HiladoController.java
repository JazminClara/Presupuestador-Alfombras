package com.dimensionrug.presupuestar.controllers;

import com.dimensionrug.presupuestar.services.HiladoService;

public class HiladoController {
    private HiladoService hiladoService;

    public HiladoController(HiladoService hiladoService) {
        this.hiladoService = hiladoService;
    }
}
