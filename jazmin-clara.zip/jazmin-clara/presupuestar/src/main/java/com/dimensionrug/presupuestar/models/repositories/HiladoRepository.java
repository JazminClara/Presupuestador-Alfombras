package com.dimensionrug.presupuestar.models.repositories;

import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.stereotype.Repository;

import com.dimensionrug.presupuestar.models.entities.Hilado;
import com.dimensionrug.presupuestar.models.repositories.interfaces.I_HiladoRepository;

@Repository
public class HiladoRepository implements I_HiladoRepository {

    private final DataSource dataSource;

    public HiladoRepository(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    private static final String SQL_CREATE = "INSERT INTO hilados (nombre, color, precio_kilo, consumo_m2, precio_m2) values (?,?,?,?,?)";
    private static final String SQL_UPDATE = "UPDATE hilados SET nombre=?, color=?, precio_kilo=?, consumo_m2=?, precio_m2=? WHERE id_hilado=?";
    private static final String SQL_DELETE = "DELETE FROM hilados WHERE id_hilado = ?";
    private static final String SQL_FIND_BY_ID = "SELECT * FROM hilados WHERE id_hilado=?";
    private static final String SQL_FIND_ALL = "SELECT * FROM hilados";

    @Override
    public void create(Hilado hilado) throws SQLException {
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_CREATE, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, hilado.getNombre());
            ps.setString(2, hilado.getColor());
            ps.setDouble(3, hilado.getPrecioKilo());
            ps.setDouble(4, hilado.getConsumoM2());
            ps.setDouble(5, hilado.getPrecioM2());

            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) hilado.setIdHilado(keys.getInt(1));
            }
        }
    }

    @Override
    public int update(Hilado hilado) throws SQLException {
        try (Connection conn = dataSource.getConnection(); PreparedStatement ps = conn.prepareStatement(SQL_UPDATE)) {
            ps.setString(1, hilado.getNombre());
            ps.setString(2, hilado.getColor());
            ps.setDouble(3, hilado.getPrecioKilo());
            ps.setDouble(4, hilado.getConsumoM2());
            ps.setDouble(5, hilado.getPrecioM2());
            ps.setInt(6, hilado.getIdHilado());

            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas;
        }
    }

    @Override
    public boolean delete(Integer id) throws SQLException {
        try (Connection conn = dataSource.getConnection(); PreparedStatement ps = conn.prepareStatement(SQL_DELETE)) {
            ps.setInt(1, id);

            boolean hiladoBorrado = ps.executeUpdate() == 1;
            return hiladoBorrado;
        }
    }

    @Override
    public Hilado findById(Integer id) throws SQLException {
        try (Connection conn = dataSource.getConnection(); PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_ID)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapRow(rs);
                return null;
            }
        }
    }

    @Override
    public List<Hilado> findAll() throws SQLException {
        List<Hilado> lista = new ArrayList<>();
        try (Connection conn = dataSource.getConnection(); PreparedStatement ps = conn.prepareStatement(SQL_FIND_ALL);
                ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(mapRow(rs));
            }
        }
        return lista;
    }

    private Hilado mapRow(ResultSet rs) throws SQLException{
        Hilado hilado = new Hilado();
        hilado.setIdHilado(rs.getInt("id_hilado"));
        hilado.setNombre(rs.getString("nombre"));
        hilado.setColor(rs.getString("color"));
        hilado.setPrecioKilo(rs.getDouble("precio_kilo"));
        hilado.setConsumoM2(rs.getDouble("consumo_m2"));
        hilado.setPrecioM2(rs.getDouble("precio_m2"));
        hilado.calcularPrecioM2();
        return hilado;
    }
}
