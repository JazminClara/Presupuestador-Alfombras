package com.dimensionrug.presupuestar.models.repositories.interfaces;

import java.sql.SQLException;
import java.util.List;

import com.dimensionrug.presupuestar.models.entities.Tela;

public interface I_TelaRepository {
    public void create(Tela tela) throws SQLException;
    public int update(Tela tela) throws SQLException;
    public boolean delete(Integer id) throws SQLException;
    public Tela findById(Integer id) throws SQLException;
    public List<Tela> findAll() throws SQLException;
}
