package com.dimensionrug.presupuestar.models.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ManoDeObra {
    private Integer idTrabajo;
    private String nombre;
    private Double precioHora;
}
