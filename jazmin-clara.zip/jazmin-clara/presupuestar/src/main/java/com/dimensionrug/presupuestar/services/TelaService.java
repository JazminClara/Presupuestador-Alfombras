package com.dimensionrug.presupuestar.services;

import java.sql.SQLException;
import java.util.List;

import org.springframework.stereotype.Service;

import com.dimensionrug.presupuestar.models.entities.Tela;
import com.dimensionrug.presupuestar.models.repositories.interfaces.I_TelaRepository;

@Service
public class TelaService {
    private final I_TelaRepository telaRepository;

    public TelaService(I_TelaRepository telaRepository) {
        this.telaRepository = telaRepository;
    }

    public List<Tela> obtenerTodasLasTelas() throws SQLException {
        return telaRepository.findAll();
    }
    
    public Tela guardarTela(Tela tela) throws SQLException {
        if (tela.getAnchoFabrica() !=0) {
            tela.setPrecioM2(tela.getPrecioMetro() / tela.getAnchoFabrica());
        } else {
            throw new IllegalArgumentException("El ancho de fabrica no puede ser 0 (cero)");
        }
        if (tela.getIdTela() != null) {
            telaRepository.update(tela);
        } else {
            telaRepository.create(tela);
        }
        return tela;
    }

    public Tela buscarTelaPorIdTela(Integer id) throws SQLException {
        return telaRepository.findById(id);
    }
 
    public boolean eliminarTela(Integer id) throws SQLException {
        return telaRepository.delete(id);
    }
}
