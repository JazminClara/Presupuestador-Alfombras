package com.dimensionrug.presupuestar.models.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Presupuesto {
    private Integer idPresupuesto;
    private String nombreCliente;
    private Double anchoAlfombra;
    private Double largoAlfombra;
    private Integer idTelaBase;
    private Tela telaBase;
    private Integer idTelaFondo;
    private Tela telaFondo;
    private Integer idHilado;
    private Hilado hilado;
    private Integer idPegamento;
    private Pegamento pegamento;
    private Integer idTrabajo;
    private ManoDeObra trabajo;
    private Double precioTotal;

    public Presupuesto(Integer idPresupuesto, String nombreCliente, Double anchoAlfombra, Double largoAlfombra,
            Integer idTelaBase, Integer idTelaFondo, Integer idHilado, Integer idPegamento, Integer idTrabajo,
            Double precioTotal) {
        this.idPresupuesto = idPresupuesto;
        this.nombreCliente = nombreCliente;
        this.anchoAlfombra = anchoAlfombra;
        this.largoAlfombra = largoAlfombra;
        this.idTelaBase = idTelaBase;
        this.idTelaFondo = idTelaFondo;
        this.idHilado = idHilado;
        this.idPegamento = idPegamento;
        this.idTrabajo = idTrabajo;
        this.precioTotal = precioTotal;
    }
}