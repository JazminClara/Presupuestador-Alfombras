package com.dimensionrug.presupuestar.models.repositories.interfaces;

import java.sql.SQLException;
import java.util.List;

import com.dimensionrug.presupuestar.models.entities.Hilado;

public interface I_HiladoRepository {
    public void create(Hilado hilado) throws SQLException;
    public int update(Hilado hilado) throws SQLException;
    public boolean delete(Integer id) throws SQLException;
    public Hilado findById(Integer id) throws SQLException;
    public List<Hilado> findAll() throws SQLException;
}
