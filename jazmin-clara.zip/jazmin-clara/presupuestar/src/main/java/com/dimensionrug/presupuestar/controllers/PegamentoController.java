package com.dimensionrug.presupuestar.controllers;


import com.dimensionrug.presupuestar.services.PegamentoService;

public class PegamentoController {
    private PegamentoService pegamentoService;

    public PegamentoController(PegamentoService pegamentoService) {
        this.pegamentoService = pegamentoService;
    }
}
