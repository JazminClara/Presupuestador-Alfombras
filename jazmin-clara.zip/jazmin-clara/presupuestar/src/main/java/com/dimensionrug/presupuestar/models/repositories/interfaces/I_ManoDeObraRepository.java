package com.dimensionrug.presupuestar.models.repositories.interfaces;

import java.sql.SQLException;
import java.util.List;

import com.dimensionrug.presupuestar.models.entities.ManoDeObra;

public interface I_ManoDeObraRepository {
    public void create(ManoDeObra manoDeObra) throws SQLException;
    public int update(ManoDeObra manoDeObra) throws SQLException;
    public boolean delete(Integer id) throws SQLException;
    public ManoDeObra findById(Integer id) throws SQLException;
    public List<ManoDeObra> findAll() throws SQLException;
}
