package com.dimensionrug.presupuestar.controllers;

import com.dimensionrug.presupuestar.services.ManoDeObraService;

public class ManoDeObraController {
    private final ManoDeObraService manoDeObraService;

    public ManoDeObraController(ManoDeObraService manoDeObraService) {
        this.manoDeObraService = manoDeObraService;
    }
}
