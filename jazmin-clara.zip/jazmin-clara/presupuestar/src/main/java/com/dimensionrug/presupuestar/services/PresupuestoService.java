package com.dimensionrug.presupuestar.services;

import java.sql.SQLException;
import java.util.List;

import org.springframework.stereotype.Service;

import com.dimensionrug.presupuestar.models.entities.Presupuesto;
import com.dimensionrug.presupuestar.models.repositories.interfaces.I_PresupuestoRepository;

@Service
public class PresupuestoService {
    private final I_PresupuestoRepository presupuestoRepository;
    private final TelaService telaService;
    private final HiladoService hiladoService;
    private final PegamentoService pegamentoService;
    private final ManoDeObraService manoDeObraService;

    public PresupuestoService(I_PresupuestoRepository presupuestoRepository, TelaService telaService,
            HiladoService hiladoService, PegamentoService pegamentoService, ManoDeObraService manoDeObraService) {
        this.presupuestoRepository = presupuestoRepository;
        this.telaService = telaService;
        this.hiladoService = hiladoService;
        this.pegamentoService = pegamentoService;
        this.manoDeObraService = manoDeObraService;
    }

    public List<Presupuesto> obtenerTodosLosPresupuestos() throws SQLException {
        return presupuestoRepository.findAll();
    }

    public Presupuesto guardarPresupuesto(Presupuesto presupuesto) throws SQLException {
        presupuesto.setPrecioTotal(presupuestar(presupuesto));
        if (presupuesto.getIdPresupuesto() != null) {
            presupuestoRepository.update(presupuesto);
        } else {
            presupuestoRepository.create(presupuesto);
        }
        return presupuesto;
    }

    public Presupuesto buscaPresupuestoPorId(Integer id) throws SQLException {
        return presupuestoRepository.findById(id);
    }

    public boolean eliminarPresupuesto(Integer id) throws SQLException {
        return presupuestoRepository.delete(id);
    }

    private Double calcularTelaBase(Presupuesto presupuesto) throws SQLException {
        Double precioM2Tela = telaService.buscarTelaPorIdTela(presupuesto.getIdTelaBase()).getPrecioM2();
        Double m2Presupuesto = presupuesto.getAnchoAlfombra() * presupuesto.getLargoAlfombra();
        return precioM2Tela * m2Presupuesto;
    }

    private Double calcularTelaFondo(Presupuesto presupuesto) throws SQLException {
        Double precioM2Tela = telaService.buscarTelaPorIdTela(presupuesto.getIdTelaFondo()).getPrecioM2();
        Double m2Presupuesto = presupuesto.getAnchoAlfombra() * presupuesto.getLargoAlfombra();
        return precioM2Tela * m2Presupuesto;
    }

    private Double calcularHilado(Presupuesto presupuesto) throws SQLException {
        Double precioM2Hilado = hiladoService.buscarHiladoPorId(presupuesto.getIdHilado()).getPrecioM2();
        Double m2Presupuesto = presupuesto.getAnchoAlfombra() * presupuesto.getLargoAlfombra();
        return precioM2Hilado * m2Presupuesto;
    }

    private Double calcularPegamento(Presupuesto presupuesto) throws SQLException {
        Double precioM2Pegamento =pegamentoService.buscarPegamentoPorId(presupuesto.getIdPegamento()).getPrecioM2();
        Double m2Presupuesto = presupuesto.getAnchoAlfombra() * presupuesto.getLargoAlfombra();
        return precioM2Pegamento * m2Presupuesto;
    }

    private Double calcularTrabajo(Presupuesto presupuesto) throws SQLException{
        Double precioHora = manoDeObraService.buscarManoDeObraPorId(presupuesto.getIdTrabajo()).getPrecioHora();
        Double m2Presupuesto = presupuesto.getAnchoAlfombra() * presupuesto.getLargoAlfombra();
        return precioHora * m2Presupuesto;
    }

    public Double presupuestar(Presupuesto presupuesto) throws SQLException {
        Double precioTotal = calcularTelaBase(presupuesto) + calcularTelaFondo(presupuesto) + 
        calcularHilado(presupuesto) + calcularPegamento(presupuesto) + calcularTrabajo(presupuesto);
        return precioTotal;
    }
}
