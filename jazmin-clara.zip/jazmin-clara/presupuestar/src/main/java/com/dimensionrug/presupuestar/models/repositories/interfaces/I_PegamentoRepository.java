package com.dimensionrug.presupuestar.models.repositories.interfaces;

import java.sql.SQLException;
import java.util.List;

import com.dimensionrug.presupuestar.models.entities.Pegamento;

public interface I_PegamentoRepository {
    public void create(Pegamento pegamento) throws SQLException;
    public int update(Pegamento pegamento) throws SQLException;
    public boolean delete(Integer id) throws SQLException;
    public Pegamento findById(Integer id) throws SQLException;
    public List<Pegamento> findAll() throws SQLException;
}
