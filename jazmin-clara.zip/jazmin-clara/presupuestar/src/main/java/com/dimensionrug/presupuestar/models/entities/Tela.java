package com.dimensionrug.presupuestar.models.entities;

import com.dimensionrug.presupuestar.models.enums.Uso;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class Tela {
    private Integer idTela;
    private String nombre;
    private Uso uso;
    private Double anchoFabrica;
    private Double precioMetro;
    private Double precioM2;

    public Tela(Integer idTela, String nombre, Uso uso, Double anchoFabrica, Double precioMetro) {
        this.idTela = idTela;
        this.nombre = nombre;
        this.uso = uso;
        this.anchoFabrica = anchoFabrica;
        this.precioMetro = precioMetro;
        if (anchoFabrica != 0) this.precioM2 = precioMetro / anchoFabrica;
    }
}
