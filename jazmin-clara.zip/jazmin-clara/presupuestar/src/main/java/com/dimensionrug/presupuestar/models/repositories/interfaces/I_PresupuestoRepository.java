package com.dimensionrug.presupuestar.models.repositories.interfaces;

import java.sql.SQLException;
import java.util.List;

import com.dimensionrug.presupuestar.models.entities.Presupuesto;

public interface I_PresupuestoRepository {
    public void create(Presupuesto presupuesto) throws SQLException;
    public int update(Presupuesto presupuesto) throws SQLException;
    public boolean delete(Integer id) throws SQLException;
    public Presupuesto findById(Integer id) throws SQLException;
    public List<Presupuesto> findAll() throws SQLException;
    public List<Presupuesto> addObjects() throws SQLException;
}
