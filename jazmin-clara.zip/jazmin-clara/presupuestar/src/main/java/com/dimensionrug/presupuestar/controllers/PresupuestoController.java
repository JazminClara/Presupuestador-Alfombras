package com.dimensionrug.presupuestar.controllers;

import java.sql.SQLException;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.dimensionrug.presupuestar.models.entities.Hilado;
import com.dimensionrug.presupuestar.models.entities.ManoDeObra;
import com.dimensionrug.presupuestar.models.entities.Pegamento;
import com.dimensionrug.presupuestar.models.entities.Presupuesto;
import com.dimensionrug.presupuestar.models.entities.Tela;
import com.dimensionrug.presupuestar.services.HiladoService;
import com.dimensionrug.presupuestar.services.ManoDeObraService;
import com.dimensionrug.presupuestar.services.PegamentoService;
import com.dimensionrug.presupuestar.services.PresupuestoService;
import com.dimensionrug.presupuestar.services.TelaService;

@Controller
public class PresupuestoController {
    private final HiladoService hiladoService;
    private final ManoDeObraService manoDeObraService;
    private final PegamentoService pegamentoService;
    private final PresupuestoService presupuestoService;
    private final TelaService telaService;

    public PresupuestoController(HiladoService hiladoService, ManoDeObraService manoDeObraService,
            PegamentoService pegamentoService, PresupuestoService presupuestoService, TelaService telaService) {
        this.hiladoService = hiladoService;
        this.manoDeObraService = manoDeObraService;
        this.pegamentoService = pegamentoService;
        this.presupuestoService = presupuestoService;
        this.telaService = telaService;
    }

    @GetMapping("/")
    public String index(Model model) {
        try {
            List<Presupuesto> presupuestos = presupuestoService.obtenerTodosLosPresupuestos();
            model.addAttribute("presupuestos", presupuestos);
            List<Tela> telas = telaService.obtenerTodasLasTelas();
            model.addAttribute("telas", telas);
            List<Hilado> hilados = hiladoService.obtenerTodosLosHilados();
            model.addAttribute("hilados", hilados);
            List<Pegamento> pegamentos = pegamentoService.obtenerTodosLosPegamentos();
            model.addAttribute("pegamentos", pegamentos);
            List<ManoDeObra> manosDeObras = manoDeObraService.obtenerTodasLasManosDeObra();
            model.addAttribute("manosDeObra", manosDeObras);
        } catch (SQLException e) {
            e.printStackTrace();
            model.addAttribute("error", "Error al cargar presupuestos!" + e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            model.addAttribute("error", "Error inesperado!" + e.getMessage());
        }
        return "index";
    }

    @GetMapping("/presupuesto/alta")
    public String altaPresupuestoForm(Model model) {
        model.addAttribute("presupuesto", new Presupuesto());
        try {
            List<Tela> telas = telaService.obtenerTodasLasTelas();
            model.addAttribute("telas", telas);
            List<Hilado> hilados = hiladoService.obtenerTodosLosHilados();
            model.addAttribute("hilados", hilados);
            List<Pegamento> pegamentos = pegamentoService.obtenerTodosLosPegamentos();
            model.addAttribute("pegamentos", pegamentos);
            List<ManoDeObra> manosDeObras = manoDeObraService.obtenerTodasLasManosDeObra();
            model.addAttribute("manosDeObras", manosDeObras);
        } catch (SQLException e) {
            e.printStackTrace();
            model.addAttribute("errorTablas", "Error al cargar tablas" + e.getMessage());
        }
        return "presupuesto-alta";
    }

    @PostMapping("/presupuesto/guardar")
    public String guardarPresupuesto(@ModelAttribute("presupuesto") Presupuesto presupuesto, Model model) {
        try {
            presupuestoService.guardarPresupuesto(presupuesto);
            return "redirect:/";
        } catch (SQLException e) {
            e.printStackTrace();
            model.addAttribute("errorForm", "Error al guardar el presupuesto" + e.getMessage());
            try {
                model.addAttribute("telas", telaService.obtenerTodasLasTelas());
                model.addAttribute("hilados", hiladoService.obtenerTodosLosHilados());
                model.addAttribute("pegamentos", pegamentoService.obtenerTodosLosPegamentos());
                model.addAttribute("manosDeObras", manoDeObraService.obtenerTodasLasManosDeObra());
            } catch (SQLException ex) {
                ex.printStackTrace();
                model.addAttribute("errorForm2", "Error al listado presupuesto luego de un guardado fallido" + e.getMessage());
            }
            return "presupuesto-alta";
        } catch (Exception ex) {
            try {
                model.addAttribute("telas", telaService.obtenerTodasLasTelas());
                model.addAttribute("hilados", hiladoService.obtenerTodosLosHilados());
                model.addAttribute("pegamentos", pegamentoService.obtenerTodosLosPegamentos());
                model.addAttribute("manosDeObras", manoDeObraService.obtenerTodasLasManosDeObra());
            } catch (Exception e) {
                ex.printStackTrace();
                model.addAttribute("error", "Error al guardar presupuesto" + ex.getMessage());
            }
            return "presupuesto-alta";
        }
    }

    @GetMapping("/presupuesto/editar")
    public String editarPresupuesto(@RequestParam("id") int id, Model model) {
        try {
            Presupuesto presupuesto = presupuestoService.buscaPresupuestoPorId(id);
            if (presupuesto != null) {
                model.addAttribute("presupuesto", presupuesto);
                List<Tela> telas = telaService.obtenerTodasLasTelas();
                model.addAttribute("telas", telas);
                List<Hilado> hilados = hiladoService.obtenerTodosLosHilados();
                model.addAttribute("hilados", hilados);
                List<Pegamento> pegamentos = pegamentoService.obtenerTodosLosPegamentos();
                model.addAttribute("pegamentos", pegamentos);
                List<ManoDeObra> manosDeObras = manoDeObraService.obtenerTodasLasManosDeObra();
                model.addAttribute("manosDeObras", manosDeObras);
                return "presupuesto-editar";
            } else {
                return "redirect:/";
            }
        } catch (SQLException e) {
            e.printStackTrace();
            model.addAttribute("errorEditarPresupuesto", "Error al cargar presupuesto para editar" + e.getMessage());
            return "redirect:/";
        }
    }

    @PostMapping("/presupuesto/actualizar")
    public String actualizarPresupuesto(@ModelAttribute("presupuesto") Presupuesto presupuesto, Model model) {
        try {
            presupuestoService.guardarPresupuesto(presupuesto);
            return "redirect:/";
        } catch (SQLException e) {
            e.printStackTrace();
            model.addAttribute("errorActualizarPresupuesto", "Error al actualizar datos del presupuesto" + e.getMessage());
            try {
                model.addAttribute("telas", telaService.obtenerTodasLasTelas());
                model.addAttribute("hilados", hiladoService.obtenerTodosLosHilados());
                model.addAttribute("pegamentos", pegamentoService.obtenerTodosLosPegamentos());
                model.addAttribute("manosDeObras", manoDeObraService.obtenerTodasLasManosDeObra());
            } catch (SQLException ex) {
                ex.printStackTrace();
                model.addAttribute("errorTablas", "Error al cargar tablas" + e.getMessage());
            }
            return "presupuesto-editar";
        } catch (Exception e) {
            e.printStackTrace();
            model.addAttribute("error", e.getMessage());
            try {
                model.addAttribute("telas", telaService.obtenerTodasLasTelas());
                model.addAttribute("hilados", hiladoService.obtenerTodosLosHilados());
                model.addAttribute("pegamentos", pegamentoService.obtenerTodosLosPegamentos());
                model.addAttribute("manosDeObras", manoDeObraService.obtenerTodasLasManosDeObra());
            } catch (SQLException ex) {
                ex.printStackTrace();
                model.addAttribute("errorTablas2", "Error al cargar tablas" + e.getMessage());
            }
            return "presupuesto-editar";
        }
    }

    @GetMapping("/presupuesto/presupuestar")
    public String calcularPresupuesto(@RequestParam("id") int id, Model model) {
        try {
            presupuestoService.guardarPresupuesto(presupuestoService.buscaPresupuestoPorId(id));
        } catch (SQLException e) {
            e.printStackTrace();
            model.addAttribute("errorBotonPresupuestar", "Error al presupuestar" + e.getMessage());
            return "redirect:/";
        }
        return "redirect:/";
    }

    @GetMapping("/presupuesto/eliminar")
    public String eliminarPresupuesto(@RequestParam("id") int id, Model model) {
        try {
            presupuestoService.eliminarPresupuesto(id);
            return "redirect:/";
        } catch (SQLException e) {
            e.printStackTrace();
            model.addAttribute("error", "Error al eliminar presupuesto id:" + id + e.getMessage());
            try {
                model.addAttribute("presupuestos", presupuestoService.obtenerTodosLosPresupuestos());
            } catch (Exception ex) {
                ex.printStackTrace();
                model.addAttribute("errorPresupuestos", "Error al cargar los presupuestos" + e.getMessage());
            }
            return "index";
        }
    }
}
