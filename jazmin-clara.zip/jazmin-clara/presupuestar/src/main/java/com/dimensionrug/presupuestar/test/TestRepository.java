package com.dimensionrug.presupuestar.test;

import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import com.dimensionrug.presupuestar.models.entities.Hilado;
import com.dimensionrug.presupuestar.models.entities.ManoDeObra;
import com.dimensionrug.presupuestar.models.entities.Pegamento;
import com.dimensionrug.presupuestar.models.entities.Presupuesto;
import com.dimensionrug.presupuestar.models.entities.Tela;
import com.dimensionrug.presupuestar.models.enums.Uso;
import com.dimensionrug.presupuestar.models.repositories.HiladoRepository;
import com.dimensionrug.presupuestar.models.repositories.ManoDeObraRepository;
import com.dimensionrug.presupuestar.models.repositories.PegamentoRepository;
import com.dimensionrug.presupuestar.models.repositories.PresupuestoRepository;
import com.dimensionrug.presupuestar.models.repositories.TelaRepository;
import com.dimensionrug.presupuestar.models.repositories.interfaces.I_HiladoRepository;
import com.dimensionrug.presupuestar.models.repositories.interfaces.I_ManoDeObraRepository;
import com.dimensionrug.presupuestar.models.repositories.interfaces.I_PegamentoRepository;
import com.dimensionrug.presupuestar.models.repositories.interfaces.I_PresupuestoRepository;
import com.dimensionrug.presupuestar.models.repositories.interfaces.I_TelaRepository;

@SpringBootApplication(scanBasePackages = "com.dimensionrug.presupuestar")
public class TestRepository {
    public static void main(String[] args) {
        try (ConfigurableApplicationContext context = SpringApplication.run(TestRepository.class, args);) {
            I_HiladoRepository hiladoRepository = context.getBean(HiladoRepository.class);
            I_ManoDeObraRepository manoDeObraRepository = context.getBean(ManoDeObraRepository.class);
            I_PegamentoRepository pegamentoRepository = context.getBean(PegamentoRepository.class);
            I_PresupuestoRepository presupuestoRepository = context.getBean(PresupuestoRepository.class);
            I_TelaRepository telaRepository = context.getBean(TelaRepository.class);

            // ===========================================  TEST  ===========================================
            // =========================================== HILADO ===========================================
            // CREAR
            System.out.println("H1) ======= Crear HILADO =======");
            Hilado hilado = new Hilado(0, "Lana", "Amarillo", 76000.0, 1.5);
            hiladoRepository.create(hilado);
            if (hilado.getIdHilado() > 0) {
                System.out.printf("Hilado: %s, creado EXITOSAMENTE con id: %d\n", hilado.getNombre(), hilado.getIdHilado());
                System.out.println(hilado);
            } else {
                System.out.println("ERROR al crear el hilado !");
            }

            // ACTUALIZAR
            System.out.printf("H2) ======= Actualizar HILADO (%d) =======\n", hilado.getIdHilado());
            hilado.setPrecioKilo(85000.0);
            int hiladosAfectados = hiladoRepository.update(hilado);
            if (hiladosAfectados == 1) {
                System.out.printf("Hilado id: %s, actualizado EXITOSAMENTE\n", hilado.getIdHilado());
                System.out.println(hilado);
            } else {
                System.out.println("ERROR al actualizar el hilado !");
            }

            // BORRAR
            System.out.printf("H3) ======= Borrar HILADO (%d) =======\n", hilado.getIdHilado());
            boolean hiladoBorrado = hiladoRepository.delete(hilado.getIdHilado());
            if (hiladoBorrado) {
                System.out.printf("Hilado id: %d eliminado EXITOSAMENTE\n", hilado.getIdHilado());
            } else {
                System.out.printf("Hilado %d no se pudo eliminar", hilado.getIdHilado());
            }

            // BUSCAR ID
            System.out.println("H4) ======= Buscando HILADO por ID (11) =======");
            Hilado hiladoEncontrado = hiladoRepository.findById(11);
            if (hiladoEncontrado != null) {
                System.out.printf("Hilado con id: %d encontrado CORRECTAMENTE\n", hiladoEncontrado.getIdHilado());
                System.out.println(hiladoEncontrado);
            } else {
                System.out.println("ERROR al buscar hilado id: 11");
            }

            // BUSCAR HILADO INEXISTENTE
            System.out.println("H5) ======= Buscando HILADO por id (777) =======");
            Hilado hiladoNoEncontrado = hiladoRepository.findById(777);
            if (hiladoNoEncontrado != null) {
                System.out.printf("Hilado con id: %d encontrado CORRECTAMENTE\n", hiladoNoEncontrado.getIdHilado());
            } else {
                System.out.println("ERROR al buscar hilado id: 777");
            }
            
            // ENCONTRAR TODOS
            System.out.println("H6) ======= LISTA DE HILADOS =======");
            List<Hilado> todosLosHilados = hiladoRepository.findAll();
            if (!todosLosHilados.isEmpty()) {
                System.out.printf("Cantidad de hilados encontrados: %d\n", todosLosHilados.size());
                todosLosHilados.forEach(System.out::println);
            } else {
                System.out.println("ERROR al buscar hilados");
            }

            // =========================================== MANO DE OBRA ===========================================
            // CREAR
            System.out.println("\nTR1) ======= Crear MANO DE OBRA =======");
            ManoDeObra trabajo = new ManoDeObra(0, "tufting", 2500.0);
            manoDeObraRepository.create(trabajo);
            if (trabajo.getIdTrabajo() > 0) {
                System.out.printf("Trabajo: %s, creada EXITOSAMENTE con id: %d\n", trabajo.getNombre(), trabajo.getIdTrabajo());
                System.out.println(trabajo);
            } else {
                System.out.println("ERROR al crear el registro de trabajo !");
            }
            
            ManoDeObra marketing = new ManoDeObra(0, "marketing", 4000.0);
            manoDeObraRepository.create(marketing);
            if (marketing.getIdTrabajo() > 0) {
                System.out.printf("Trabajo: %s, creada EXITOSAMENTE con id: %d\n", marketing.getNombre(), marketing.getIdTrabajo());
                System.out.println(marketing);
            } else {
                System.out.println("ERROR al crear el registro de trabajo !");
            }

            ManoDeObra rrhh = new ManoDeObra(0, "rrhh", 3000.0);
            manoDeObraRepository.create(rrhh);
            if (rrhh.getIdTrabajo() > 0) {
                System.out.printf("Trabajo: %s, creada EXITOSAMENTE con id: %d\n", rrhh.getNombre(), rrhh.getIdTrabajo());
                System.out.println(rrhh);
            } else {
                System.out.println("ERROR al crear el registro de trabajo !");
            }

            // ACTUALIZAR
            System.out.printf("TR2) ======= Actualizar TRABAJO (%d) =======\n", trabajo.getIdTrabajo());
            trabajo.setPrecioHora(55000.0);
            int trabajosAfectados = manoDeObraRepository.update(trabajo);
            if (trabajosAfectados == 1) {
                System.out.printf("Tela id: %s, actualizado EXITOSAMENTE\n", trabajo.getIdTrabajo());
                System.out.println(trabajo);
            } else {
                System.out.println("ERROR al actualizar el registro de trabajo !");
            }

            // BORRAR
            System.out.printf("TR3) ======= Borrar TRABAJO (%d) =======\n", trabajo.getIdTrabajo());
            boolean trabajoBorrado = manoDeObraRepository.delete(trabajo.getIdTrabajo());
            if (trabajoBorrado) {
                System.out.printf("Trabajo id: %d eliminado EXITOSAMENTE\n", trabajo.getIdTrabajo());
            } else {
                System.out.printf("Trabajo %d no se pudo eliminar", trabajo.getIdTrabajo());
            }

            // BUSCAR ID
            System.out.println("TR4) ======= Buscando TRABAJO por ID (3) =======");
            ManoDeObra trabajoEncontrado = manoDeObraRepository.findById(3);
            if (trabajoEncontrado != null) {
                System.out.printf("Trabajo con id: %d encontrado CORRECTAMENTE\n", trabajoEncontrado.getIdTrabajo());
                System.out.println(trabajoEncontrado);
            } else {
                System.out.println("ERROR al buscar trabajo id: 3");
            }

            // BUSCAR HILADO INEXISTENTE
            System.out.println("TR5) ======= Buscando TRABAJO por id (777) =======");
            ManoDeObra trabajoNoEncontrado = manoDeObraRepository.findById(777);
            if (trabajoNoEncontrado != null) {
                System.out.printf("Trabajo con id: %d encontrado CORRECTAMENTE\n", trabajoNoEncontrado.getIdTrabajo());
            } else {
                System.out.println("ERROR al buscar trabajo id: 777");
            }
            
            // ENCONTRAR TODOS
            System.out.println("TR6) ======= LISTA DE TRABAJOS =======");
            List<ManoDeObra> todosLosTrabajos = manoDeObraRepository.findAll();
            if (!todosLosTrabajos.isEmpty()) {
                System.out.printf("Cantidad de trabajos encontrados: %d\n", todosLosTrabajos.size());
                todosLosTrabajos.forEach(System.out::println);
            } else {
                System.out.println("ERROR al buscar trabajos");                                                                                                                                                   
            }

            // =========================================== PEGAMENTO ===========================================
            // CREAR
            System.out.println("\nPE1) ======= Crear PEGAMENTO =======");
            Pegamento pegamento = new Pegamento(0, "Epoxi", 11000.0, 750.0);
            pegamentoRepository.create(pegamento);
            if (pegamento.getIdPegamento() > 0) {
                System.out.printf("Pegamento: %s, creado EXITOSAMENTE con id: %d\n", pegamento.getNombre(), pegamento.getIdPegamento());
                System.out.println(pegamento);
            } else {
                System.out.println("ERROR al crear el pegamento !");
            }

            // ACTUALIZAR
            System.out.printf("PE2) ======= Actualizar PEGAMENTO (%d) =======\n", pegamento.getIdPegamento());
            pegamento.setPrecioKilo(11500.0);
            int pegamentosAfectados = pegamentoRepository.update(pegamento);
            if (pegamentosAfectados == 1) {
                System.out.printf("Pegamento id: %s, actualizado EXITOSAMENTE\n", pegamento.getIdPegamento());
                System.out.println(pegamento);
            } else {
                System.out.println("ERROR al actualizar el pegamento !");
            }

            // BORRAR
            System.out.printf("PE3) ======= Borrar PEGAMENTO (%d) =======\n", pegamento.getIdPegamento());
            boolean pegamentoBorrado = pegamentoRepository.delete(pegamento.getIdPegamento());
            if (pegamentoBorrado) {
                System.out.printf("Pegamento id: %d eliminado EXITOSAMENTE\n", pegamento.getIdPegamento());
            } else {
                System.out.printf("Pegamento %d no se pudo eliminar", pegamento.getIdPegamento());
            }

            // BUSCAR ID
            System.out.println("PE4) ======= Buscando PEGAMENTO por ID (11) =======");
            Pegamento pegamentoEncontrado = pegamentoRepository.findById(11);
            if (pegamentoEncontrado != null) {
                System.out.printf("Pegamento con id: %d encontrado CORRECTAMENTE\n", pegamentoEncontrado.getIdPegamento());
                System.out.println(pegamentoEncontrado);
            } else {
                System.out.println("ERROR al buscar pegamento id: 11");
            }

            // BUSCAR HILADO INEXISTENTE
            System.out.println("PE5) ======= Buscando PEGAMENTO por id (777) =======");
            Pegamento pegamentoNoEncontrado = pegamentoRepository.findById(777);
            if (pegamentoNoEncontrado != null) {
                System.out.printf("Pegamento con id: %d encontrado CORRECTAMENTE\n", pegamentoNoEncontrado.getIdPegamento());
            } else {
                System.out.println("ERROR al buscar pegamento id: 777");
            }
            
            // ENCONTRAR TODOS
            System.out.println("PE6) ======= LISTA DE PEGAMENTOS =======");
            List<Pegamento> todosLosPegamentos = pegamentoRepository.findAll();
            if (!todosLosPegamentos.isEmpty()) {
                System.out.printf("Cantidad de pegamentos encontrados: %d\n", todosLosPegamentos.size());
                todosLosPegamentos.forEach(System.out::println);
            } else {
                System.out.println("ERROR al buscar pegamentos");
            }

            // =========================================== PRESUPUESTO ===========================================
            // CREAR
            System.out.println("\nPR1) ======= Crear PRESUPUESTO =======");
            Presupuesto presupuesto = new Presupuesto(0, "Teresa", 1.8, 1.1, 3, 8, 5, 1, 1, null);
            presupuestoRepository.create(presupuesto);
            if (presupuesto.getIdPresupuesto() > 0) {
                System.out.printf("Presupuesto de: %s, creado EXITOSAMENTE con id: %d\n", presupuesto.getNombreCliente(), presupuesto.getIdPresupuesto());
                System.out.println(presupuesto);
            } else {
                System.out.println("ERROR al crear presupuesto !");
            }

            // ACTUALIZAR
            System.out.printf("PR2) ======= Actualizar Presupuesto (%d) =======\n", presupuesto.getIdPresupuesto());
            presupuesto.setIdTelaBase(5);
            int presupuestosAfectados = presupuestoRepository.update(presupuesto);
            if (presupuestosAfectados == 1) {
                System.out.printf("Presupuesto id: %d, actualizado EXITOSAMENTE\n", presupuesto.getIdPresupuesto());
                System.out.println(presupuesto);
            } else {
                System.out.println("ERROR al actualizar presupuesto !");
            }

            // BORRAR
            System.out.printf("PR3) ======= Borrar PRESUPUESTO (%d) =======\n", presupuesto.getIdPresupuesto());
            boolean presupuestoBorrado = presupuestoRepository.delete(presupuesto.getIdPresupuesto());
            if (presupuestoBorrado) {
                System.out.printf("Presupuesto id: %d eliminado EXITOSAMENTE\n", presupuesto.getIdPresupuesto());
            } else {
                System.out.printf("Presupuesto %d no se pudo eliminar", presupuesto.getIdPresupuesto());
            }

            // BUSCAR ID
            System.out.println("PR4) ======= Buscando PRESUPUESTO por ID (11) =======");
            Presupuesto presupuestoEncontrado = presupuestoRepository.findById(11);
            if (presupuestoEncontrado != null) {
                System.out.printf("Presupuesto con id: %d encontrado CORRECTAMENTE\n", presupuestoEncontrado.getIdPresupuesto());
                System.out.println(presupuestoEncontrado);
            } else {
                System.out.println("ERROR al buscar presupuesto id: 11");
            }

            // BUSCAR HILADO INEXISTENTE
            System.out.println("PR5) ======= Buscando PRESUPUESTO por id (777) =======");
            Presupuesto presupuestoNoEncontrado = presupuestoRepository.findById(777);
            if (presupuestoNoEncontrado != null) {
                System.out.printf("Presupuesto con id: %d encontrado CORRECTAMENTE\n", presupuestoNoEncontrado.getIdPresupuesto());
            } else {
                System.out.println("ERROR al buscar presupuesto id: 777");
            }
            
            // ENCONTRAR TODOS
            System.out.println("PR6) ======= LISTA DE PRESUPUESTOS =======");
            List<Presupuesto> todosLosPresupuestos = presupuestoRepository.findAll();
            if (!todosLosPresupuestos.isEmpty()) {
                System.out.printf("Cantidad de presupuestos encontrados: %d\n", todosLosPresupuestos.size());
                todosLosPresupuestos.forEach(System.out::println);
            } else {
                System.out.println("ERROR al buscar presupuestos");
            }

            // =========================================== TELA ===========================================
            // CREAR
            System.out.println("\nTE1) ======= Crear TELA =======");
            Tela tela = new Tela(0, "Tusor", Uso.BASE, 1.8, 4500.0);
            telaRepository.create(tela);
            if (tela.getIdTela() > 0) {
                System.out.printf("Tela id: %s, creada EXITOSAMENTE con id: %d\n", tela.getNombre(), tela.getIdTela());
                System.out.println(tela);
            } else {
                System.out.println("ERROR al crear la tela !");
            }

            // ACTUALIZAR
            System.out.printf("TE2) ======= Actualizar TELA (%d) =======\n", tela.getIdTela());
            tela.setPrecioMetro(5000.0);
            int telasAfectadas = telaRepository.update(tela);
            if (telasAfectadas == 1) {
                System.out.printf("tela: %s, actualizado EXITOSAMENTE\n", tela.getIdTela());
                System.out.println(tela);
            } else {
                System.out.println("ERROR al actualizar el tela !");
            }

            // BORRAR
            System.out.printf("TE3) ======= Borrar TELA (%d) =======\n", tela.getIdTela());
            boolean telaBorrada = telaRepository.delete(tela.getIdTela());
            if (telaBorrada) {
                System.out.printf("Tela id: %d eliminada EXITOSAMENTE\n", tela.getIdTela());
            } else {
                System.out.printf("Tela %d no se pudo eliminar", tela.getIdTela());
            }

            // BUSCAR ID
            System.out.println("T4) ======= Buscando TELA por ID (11) =======");
            Tela telaEncontrado = telaRepository.findById(11);
            if (telaEncontrado != null) {
                System.out.printf("Tela con id: %d encontrada CORRECTAMENTE\n", telaEncontrado.getIdTela());
                System.out.println(telaEncontrado);
            } else {
                System.out.println("ERROR al buscar tela id: 11");
            }

            // BUSCAR HILADO INEXISTENTE
            System.out.println("T5) ======= Buscando TELA por id (777) =======");
            Tela telaNoEncontrado = telaRepository.findById(777);
            if (telaNoEncontrado != null) {
                System.out.printf("Tela con id: %d encontrada CORRECTAMENTE\n", telaNoEncontrado.getIdTela());
            } else {
                System.out.println("ERROR al buscar tela id: 777");
            }
            
            // ENCONTRAR TODOS
            System.out.println("T6) ======= LISTA DE TELAS =======");
            List<Tela> todosLasTelas = telaRepository.findAll();
            if (!todosLasTelas.isEmpty()) {
                System.out.printf("Cantidad de telas econtradas: %d\n", todosLasTelas.size());
                todosLasTelas.forEach(System.out::println);
            } else {
                System.out.println("ERROR al buscar telas");
            }
        } catch (Exception e) {
            System.out.println("Error al usar repositorios");
            e.printStackTrace();
        } finally {
            System.out.println("<< TestRepository FINALIZADO >>\n<< CONTEXTO DE SPING CERRADO >>");
        }
    }
}
