package com.dimensionrug.presupuestar.models.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.stereotype.Repository;

import com.dimensionrug.presupuestar.models.entities.Pegamento;
import com.dimensionrug.presupuestar.models.repositories.interfaces.I_PegamentoRepository;

@Repository
public class PegamentoRepository implements I_PegamentoRepository{
    private final DataSource dataSource;

    public PegamentoRepository(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    private static final String SQL_CREATE = "INSERT INTO pegamentos (nombre, precio_kilo, consumo_m2, precio_m2) VALUES (?,?,?,?)";
    private static final String SQL_UPDATE = "UPDATE pegamentos SET nombre=?, precio_kilo=?, consumo_m2=?, precio_m2=? WHERE id_pegamento=?";
    private static final String SQL_DELETE = "DELETE FROM pegamentos WHERE id_pegamento = ?";
    private static final String SQL_FIND_BY_ID = "SELECT * FROM pegamentos WHERE id_pegamento = ?";
    private static final String SQL_FIND_ALL = "SELECT * FROM pegamentos";

    @Override
    public void create(Pegamento pegamento) throws SQLException {
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_CREATE, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, pegamento.getNombre());
            ps.setDouble(2, pegamento.getPrecioKilo());
            ps.setDouble(3, pegamento.getConsumoM2());
            ps.setDouble(4, pegamento.getPrecioM2());

            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) pegamento.setIdPegamento(keys.getInt(1));
            }
        }
    }

    @Override
    public int update(Pegamento pegamento) throws SQLException {
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_UPDATE)) {
            ps.setString(1, pegamento.getNombre());
            ps.setDouble(2, pegamento.getPrecioKilo());
            ps.setDouble(3, pegamento.getConsumoM2());
            ps.setDouble(4, pegamento.getPrecioM2());
            ps.setInt(5, pegamento.getIdPegamento());

            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas;
        }
    }

    @Override
    public boolean delete(Integer id) throws SQLException {
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_DELETE)) {
            ps.setInt(1, id);

            boolean pegamentoBorrado = ps.executeUpdate() == 1;
            return pegamentoBorrado;
        }
    }
    
    @Override
    public Pegamento findById(Integer id) throws SQLException {
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_ID)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapRow(rs);
            }
        } 
        return null;
    }

    @Override
    public List<Pegamento> findAll() throws SQLException {
        List<Pegamento> lista = new ArrayList<>();
        try (Connection conn = dataSource.getConnection(); PreparedStatement ps = conn.prepareStatement(SQL_FIND_ALL);
                ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(mapRow(rs));
            }
        } 
        return lista;
    }

    private Pegamento mapRow(ResultSet rs) throws SQLException {
        Pegamento pegamento = new Pegamento();
        pegamento.setIdPegamento(rs.getInt("id_pegamento"));
        pegamento.setNombre(rs.getString("nombre"));
        pegamento.setPrecioKilo(rs.getDouble("precio_kilo"));
        pegamento.setConsumoM2(rs.getDouble("consumo_m2"));
        pegamento.setPrecioM2(rs.getDouble("precio_m2"));
        return pegamento;
    }
}
