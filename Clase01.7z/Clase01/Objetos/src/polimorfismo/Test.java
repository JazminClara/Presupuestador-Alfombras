package polimorfismo;

public class Test {
    //creo un auto  un auto de carrera
    Auto auto = new Auto("Toyota", 0);
    Auto autoCarrerara = new AutoCarrera("Ferrari", 0, "Aleron Trasero");

    //comportamiento
    auto.acelerar(); // 0 --> 10
    autoCarrerara.acelerar(); // 0 --> 100

    //estado final
    System.out.println(auto);
    System.out.println(autoCarrera);
}
