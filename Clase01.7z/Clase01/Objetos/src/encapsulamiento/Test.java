public class Test {
    public static void main(String[] args) throws Exception {
        //Crear un objeto de tipo Auto
        Auto a1= new Auto();
        Auto a2= new Auto("Chevrolet", 0);

        //incializar objeto
        a1.setMarca("Ford");
        a1.setVeocidad(0);

        //comportamiento
        a1.acelerar(); // Acelera 10 km
        a1.acelerar(20); // Acelera 20 km

        a2.acelerar(); // Acelera 0 --> 10 km
        a2.acelerar(50); // Acelera 10 --> 60 km

        //estado final
        System.out.println("Estado inicial: " + a1);
        System.out.println("------------------");
        System.out.println(a2);
        

    }
}
