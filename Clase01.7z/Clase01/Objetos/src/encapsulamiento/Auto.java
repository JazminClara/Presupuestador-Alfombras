public class Auto {
    //Artibutos
    private String marca;
    private int velocidad;
    
    public Auto() {
    }

    public Auto(String marca, int veocidad) {
        this.setMarca(marca);
        this.setVeocidad(veocidad);
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public int getVeocidad() {
        return velocidad;
    }

    public void setVeocidad(int veocidad) {
        //regla e negocio
        if (velocidad >= 0 && velocidad <= 130) {
            this.velocidad = veocidad;
        } else{
            System.out.println("La velocidad es incorrecta");
        }        
    }

    //Metodo acelerar

    public void acelerar() {
        this.setVeocidad(this.velocidad + 10);
    }

    //Sobrecarga del metodo, con 1 parametro
    public void acelerar(int km) {
        this.setVeocidad(this.velocidad + km);
    }

    @Override
    public String toString() {
        return "marca=" + marca + ", velocidad=" + velocidad + "]";
    }



}
